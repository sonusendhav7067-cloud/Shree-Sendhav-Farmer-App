Shree Sendhav Dairy V34 - Farmer Code + 4 Digit PIN

1. Farmer Master में Farmer Code और Name भरें.
2. PIN blank छोड़ने पर software 4-digit PIN auto-generate करेगा. चाहें तो 4-digit PIN manually दें.
3. Save Farmer के बाद PIN popup में दिखेगा. Farmer को Code + PIN दें.
4. Internet/Firebase sync होने पर Farmer App में login index automatically publish होगा.
5. Farmer App login: Farmer Code + 4 Digit PIN.
6. OTP/Billing की जरूरत नहीं है.
7. Firebase Authentication में Anonymous provider ENABLE करें.
8. Firestore Rules में FIRESTORE_RULES_CODE_PIN.txt वाले rules publish करें.
9. Farmer App URL examples:
   ?plant=main
   ?plant=arandiya
   ?plant=narsinggarh
