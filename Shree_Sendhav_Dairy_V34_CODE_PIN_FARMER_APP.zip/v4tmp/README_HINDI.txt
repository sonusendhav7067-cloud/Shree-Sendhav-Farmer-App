SHREE SENDHAV DAIRY V34 - DESKTOP

Is project me current V34 ka same index.html desktop Electron ke liye diya gaya hai.
Features: same Firebase/plant login, logout, milk entry code->name auto, Enter flow, 10-day bill, purchase summary, A4 print/save features.

Windows CMD me:
1. Is folder ko Desktop par extract karein.
2. Folder ke andar address bar me cmd likhkar Enter karein.
3. npm install
4. npm run dist
5. dist folder me setup .exe milega.
