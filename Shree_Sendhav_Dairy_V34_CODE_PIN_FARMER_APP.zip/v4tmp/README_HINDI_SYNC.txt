V34 + FARMER APP AUTO SYNC V4
Milk, payments and farmer purchases are published to:
farmerPortal/{plantId}/users/{+91mobile}/entries|payments|purchases
Farmer App reads only the selected plant and registered mobile.
IMPORTANT: Publish the Firestore rules before production use.
