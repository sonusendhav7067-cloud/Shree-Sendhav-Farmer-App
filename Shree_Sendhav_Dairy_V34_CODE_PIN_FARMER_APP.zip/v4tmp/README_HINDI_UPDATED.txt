Shree Sendhav Dairy V34 - Updated Final

1. index.html खोलकर software चलाएँ.
2. Milk Entry: Farmer Code -> Enter -> Milk -> Enter -> FAT -> Enter -> SNF -> Enter -> CLR -> Enter -> Save -> Enter -> अगला Farmer Code.
3. 10-Day Bill में All Farmers चुनने पर सभी farmers के bills एक साथ बनेंगे. Print A4 में हर farmer अलग page पर होगा. Save Bill पूरा bundle HTML में save करेगा.
4. Cloud Sync default hidden है. Cloud Sync button दबाएँ और password 2580 डालें. काम के बाद Hide/Lock करें.
5. Cloud Sync plant-wise है: Main / Arandiya / Narsinggarh.
6. Farmer Complaint Inbox भी plant-wise है. पहले Plant Login करें. Arandiya में केवल Arandiya complaints, Narsinggarh में केवल Narsinggarh complaints, Main में Main complaints दिखेंगी.
7. Firebase permission error आने पर FIRESTORE_RULES_PLANT_COMPLAINTS.txt के rules Firebase Console > Firestore > Rules में publish करें.
8. पुराना data delete/clear न करें. पहले Backup लें.
