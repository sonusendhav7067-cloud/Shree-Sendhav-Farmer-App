SHREE SENDHAV DAIRY – FARMER APP V2

Features:
1. Teen Plant Selection: Main (Ashta), Arandiya, Narsinggarh
2. Farmer Code + 4 Digit PIN Login
3. Aaj ka Doodh + Morning/Evening history
4. 10-Day Bill periods: 1-10, 11-20, 21-Month End
5. Detailed bill: Milk, FAT, SNF/CLR, Amount, Products, AD, Cut-off
6. Advance Payment and Running Payment details + history
7. Product purchase history
8. Farmer complaint and reply
9. Mobile-friendly modern interface
10. Firebase Firestore integration using existing Shree Sendhav Dairy V34 project

Important:
- Existing Firestore rules must allow farmerPortal, farmerSessions and plantComplaints as configured in V34.
- Plant is selected before login. URLs can use ?plant=main, ?plant=arandiya, or ?plant=narsinggarh.
- This app is read-only for farmer records. Corrections remain in Dairy V34 admin software.
